package refactored;

import java.time.LocalDate;

public class Order {
    private String userName;
    private int productId;
    private int quantity;
    private double price;
    private String address;
    private boolean urgent;
    private String notes;
    private LocalDate date;
    private double total;

    public Order(String userName, int productId, int quantity, double price, String address,
                 boolean urgent, String notes, LocalDate date) {
        this.userName = userName;
        this.productId = productId;
        this.quantity = quantity;
        this.price = price;
        this.address = address;
        this.urgent = urgent;
        this.notes = notes;
        this.date = date;
    }

    // getters and setters
    public String getUserName() { return userName; }
    public int getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = q; }
    public double getPrice() { return price; }
    public String getAddress() { return address; }
    public boolean isUrgent() { return urgent; }
    public String getNotes() { return notes; }
    public LocalDate getDate() { return date; }
    public double getTotal() { return total; }
    public void setTotal(double t) { this.total = t; }
}
