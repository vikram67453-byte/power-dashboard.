package refactored;

public class NotificationService {
    public void notifyUser(String userName, String message) {
        System.out.println("Notification for " + userName + ": " + message);
    }
}
