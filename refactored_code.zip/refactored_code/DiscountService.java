package refactored;

public class DiscountService {
    public double applyUserTypeDiscount(int userType, double bill) {
        switch (userType) {
            case 1: return bill - 10;
            case 2: return bill - 2;
            case 3: return bill - 1;
            default: return bill;
        }
    }

    public double verifyDiscount(int userType, double bill) {
        // kept legacy method name to match original behavior (refactored to clearer name above)
        return applyUserTypeDiscount(userType, bill);
    }
}
