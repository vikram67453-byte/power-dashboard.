package refactored;

import java.io.FileWriter;
import java.io.IOException;

public class OrderRepository {
    private String path;

    public OrderRepository(String path) {
        this.path = path;
    }

    public void saveOrderSummary(Order order) {
        try (FileWriter fw = new FileWriter(path, true)) {
            fw.write("U:" + order.getUserName() + " P:" + order.getProductId() + " T:" + order.getTotal() + "\n");
        } catch (IOException e) {
            System.out.println("Write error: " + e.getMessage());
        }
    }
}
