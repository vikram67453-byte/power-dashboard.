package refactored;

public enum PaymentType {
    CASH, CARD, BANK, OTHER
}
