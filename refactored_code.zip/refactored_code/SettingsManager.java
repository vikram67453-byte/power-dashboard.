package refactored;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SettingsManager {
    private int userType = 1;
    private PaymentType paymentType = PaymentType.CASH;

    public void loadSettings(String path) {
        try {
            File f = new File(path);
            Scanner s = new Scanner(f);
            while (s.hasNextLine()) {
                String line = s.nextLine().trim();
                if (line.startsWith("U")) userType = Integer.parseInt(line.substring(2).trim());
                if (line.startsWith("P")) paymentType = PaymentType.valueOf(line.substring(2).trim());
            }
            s.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Settings not loaded: " + ex.getMessage());
        }
    }

    public int getUserType() { return userType; }
    public PaymentType getPaymentType() { return paymentType; }
}
