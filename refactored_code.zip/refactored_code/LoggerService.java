package refactored;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoggerService {
    private List<String> logs = new ArrayList<>();

    public void info(String msg) {
        logs.add("INFO: " + msg);
    }

    public void error(String msg) {
        logs.add("ERROR: " + msg);
    }

    public void exportLogs(String path) {
        try (FileWriter fw = new FileWriter(path)) {
            for (String s : logs) fw.write(s + "\n");
        } catch (IOException e) {
            System.out.println("Log export error: " + e.getMessage());
        }
    }

    public List<String> getLogs() { return logs; }
}
