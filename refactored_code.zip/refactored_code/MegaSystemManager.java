package refactored;

import java.time.LocalDate;

public class MegaSystemManager {
    private SettingsManager settings = new SettingsManager();
    private LoggerService logger = new LoggerService();
    private DiscountService discountService = new DiscountService();
    private ShippingCalculator shippingCalculator = new ShippingCalculator();
    private OrderRepository orderRepo = new OrderRepository("order_data.txt");
    private NotificationService notifier = new NotificationService();

    public MegaSystemManager() {}

    public void loadSettings() {
        settings.loadSettings("settings.conf");
    }

    public void processOrder(Order order) {
        logger.info("Start:" + order.getUserName());

        if (order.isUrgent()) {
            order.setQuantity(order.getQuantity() + 1);
        }

        if (order.getQuantity() <= 0 || order.getPrice() <= 0) {
            System.out.println("Invalid quantity or price");
            logger.error("Invalid order: " + order.getUserName());
            return;
        }

        double total = order.getQuantity() * order.getPrice() + 10 + 20; // replaced constants with explicit values (could be configurable)
        int userType = settings.getUserType();

        if (userType == 1) total -= 5;
        else if (userType == 2) total += 5;

        order.setTotal(total);
        orderRepo.saveOrderSummary(order);

        PaymentType p = settings.getPaymentType();
        switch (p) {
            case CASH: System.out.println("Cash payment"); break;
            case CARD: System.out.println("Card payment"); break;
            case BANK: System.out.println("Bank payment"); break;
            default: System.out.println("Other payment"); break;
        }

        printOrderReport(order);
        logger.info("End:" + order.getUserName());
        notifier.notifyUser(order.getUserName(), "Your order has been processed successfully!");
    }

    private void printOrderReport(Order order) {
        System.out.println("----- ORDER REPORT -----");
        System.out.println("User: " + order.getUserName());
        System.out.println("Product: " + order.getProductId());
        System.out.println("Quantity: " + order.getQuantity());
        System.out.println("Total: " + order.getTotal());
        System.out.println("Date: " + order.getDate());
    }

    public static void main(String[] args) {
        MegaSystemManager m = new MegaSystemManager();
        m.loadSettings();
        Order o = new Order("Ali", 101, 2, 999.99, "Karachi", true, "Handle carefully", LocalDate.of(2025,11,12));
        m.processOrder(o);

        double discounted = m.discountService.verifyDiscount(m.settings.getUserType(), 5000);
        System.out.println("Discounted total: " + discounted);

        int shipping = m.shippingCalculator.calculateShipping(35);
        System.out.println("Shipping cost: " + shipping);

        System.out.println();
        m.logger.exportLogs("logs.txt");
    }
}
